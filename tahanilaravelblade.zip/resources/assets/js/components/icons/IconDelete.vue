<template>
  <svg id="icon-delete" viewBox="0 0 8.6 8.6">
    <path
        d="M5.3 4.3l3-3c.3-.3.3-.8 0-1.1s-.8-.3-1.1 0l-3 3-3-3C1-.1.5-.1.2.2s-.3.8 0 1.1l3 3-3 3c-.3.3-.3.8 0 1.1.1.1.3.2.5.2s.4-.1.5-.2l3-3 3 3c.1.1.3.2.5.2s.4-.1.5-.2c.3-.3.3-.8 0-1.1l-2.9-3z" />
  </svg>
</template>

<script>
export default {

};
</script>