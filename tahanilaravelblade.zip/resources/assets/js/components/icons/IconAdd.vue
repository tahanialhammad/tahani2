<template>
  <svg id="icon-add" viewBox="0 0 11.5 11.5">
    <path d="M10.8 5H6.5V.8c0-.5-.3-.8-.7-.8S5 .3 5 .8V5H.8c-.5 0-.8.3-.8.8s.3.8.8.8H5v4.3c0 .4.3.8.8.8s.8-.3.8-.8V6.5h4.3c.4 0 .8-.3.8-.8s-.5-.7-.9-.7z"/>
  </svg>
</template>

<script>
export default {};
</script>