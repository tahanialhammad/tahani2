<template>
  <svg id="icon-down" viewBox="0 0 12.1 7.5">
    <path d="M6 7.5L0 1.4 1.4 0 6 4.6 10.7 0l1.4 1.4z"/>
  </svg>
</template>

<script>
export default {};
</script>