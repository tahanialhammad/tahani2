<template>
    <svg viewBox="0 0 11.6 11.6">
        <path d="M5.8 1.6l4.5 3.7v4.9h-9V5.4l4.5-3.8m0-1.6L0 4.8v6.8h11.6V4.8L5.8 0z" class="st0"/>
    </svg>
</template>

<script>
export default {};
</script>