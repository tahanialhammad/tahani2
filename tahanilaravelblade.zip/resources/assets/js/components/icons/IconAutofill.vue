<template>
  <svg  id="icon-autofill" viewBox="0 0 11.6 11.6">
    <path d="M1.2 4.4H0V1.6C0 .7.7 0 1.6 0h2.8v1.2H1.6c-.2 0-.4.2-.4.4v2.8zm8.7 7.2H7.2v-1.2H10c.2 0 .4-.2.4-.4V7.2h1.2V10c0 .8-.8 1.6-1.7 1.6zm1.7-7.2h-1.2V1.6c0-.2-.2-.4-.4-.4H7.2V0H10c.9 0 1.6.7 1.6 1.6v2.8zm-7.2 7.2H1.6c-.9 0-1.6-.8-1.6-1.7V7.2h1.2V10c0 .2.2.4.4.4h2.8v1.2z"/>
  </svg>
</template>

<script>
export default {};
</script>