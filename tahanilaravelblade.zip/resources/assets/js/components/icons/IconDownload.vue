<template>
  <svg id="icon-download" viewBox="0 0 11.2 11.4">
    <path d="M8.2 7L5.6 9.7 3 7h5.2m3-1.3H0l5.6 5.7 5.6-5.7zM5.6 2.9c-.4 0-.8.4-.8.8s.4.8.8.8.8-.4.8-.8c0-.5-.4-.8-.8-.8zm0-2.9c-.4 0-.8.4-.8.8s.4.8.8.8.8-.4.8-.8S6 0 5.6 0z"/>
  </svg>
</template>

<script>
export default {};
</script>