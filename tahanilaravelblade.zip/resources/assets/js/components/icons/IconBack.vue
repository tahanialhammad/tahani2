<template>
  <svg id="icon-arrow-bold" viewBox="0 0 16.1 13.1">
    <path d="M.1 6.9c0 .1.1.1.1.2l6.2 5.8c.1.1.3.2.5.2s.4-.1.5-.2c.3-.3.3-.8 0-1.1L2.6 7.3h12.7c.4 0 .8-.3.8-.8s-.3-.7-.7-.7H2.7l4.8-4.5c.3-.3.3-.8 0-1.1s-.8-.3-1.1 0L.2 6c-.1.1-.1.1-.1.2v.1c0 .1-.1.2-.1.3s.1.2.1.3z"/>
  </svg>
</template>

<script>
export default {

};
</script>