<template>
  <svg id="icon-minus" viewBox="0 0 11.6 1.5">
    <path d="M10.8 1.5H.8c-.5 0-.8-.3-.8-.7S.3 0 .8 0h10c.4 0 .8.3.8.8s-.4.7-.8.7z"
          class="st0"/>
  </svg>
</template>

<script>
export default {};
</script>