@extends('user.user-template')

@section('content')
<h1>user content </h1>
@stop 