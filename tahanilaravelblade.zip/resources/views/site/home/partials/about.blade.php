<div class="row w-75 mx-auto my-5">
    <div class="col p-4">
        <h1 class="fw-bold mb-4 px-4">My developments skills suitable for web application or website/webshop.</h1>
        <p class="p-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis quisquam quidem aspernatur aliquam dolorem vel dicta doloribus incidunt, nihil obcaecati facere illo ab eligendi magnam, architecto eum ad, voluptatibus non.</p>
    </div>
    <div class="col" >
        <img src="/images/about.svg" alt=""   
        data-aos="fade-left"
         data-aos-delay="50"
        data-aos-duration="1000"
        data-aos-easing="ease-in-out">
    </div>
</div>