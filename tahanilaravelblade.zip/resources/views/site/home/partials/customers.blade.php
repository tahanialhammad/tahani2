<div class="row">
    <div class="col-6">Over our customers</div>
    <div class="col-6">
        <glide-slider></glide-slider>
    </div>
</div>