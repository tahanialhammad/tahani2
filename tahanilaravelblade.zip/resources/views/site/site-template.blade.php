@extends('layouts.site')
@section('main')

@yield('header')

<div class="p-4">
  @yield('content')
</div>
@stop

