<div class="col d-none d-lg-block bg-warning">
    <div id="carouselMarkting" class="carousel slide h-100" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselMarkting" data-bs-slide-to="0" class="active rounded-circle" aria-current="true" aria-label="Slide 1" style="width: 10px; height: 10px"></button>
            <button type="button" data-bs-target="#carouselMarkting" data-bs-slide-to="1" class="rounded-circle" aria-label="Slide 2" style="width: 10px; height: 10px"></button>
        </div>

        <div class="carousel-inner h-100">
            <div class="carousel-item h-100 border-15 active" style="background-color:pink;">
                <img src="https://images.unsplash.com/photo-1691414061225-b9a85b1027ad?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80" class="vh-100 w-100" alt="">
                <div class="carousel-caption d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>Some representative placeholder content for the first slide.</p>
                </div>
            </div>
            <div class="carousel-item h-100 border-15" style="background-color:rgb(212, 140, 152);">
                <img src="https://images.unsplash.com/photo-1691414061225-b9a85b1027ad?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80" class="vh-100 w-100" alt="">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Second slide label</h5>
                    <p>Some representative placeholder content for the second slide.</p>
                </div>
            </div>
        </div>
    </div>
</div>
