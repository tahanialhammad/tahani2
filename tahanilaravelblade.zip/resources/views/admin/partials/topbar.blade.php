<header class="topbar sticky-top p-4 d-flex align-items-center justify-content-between bg-white text-dark">

    @include('admin.partials.topbar-left-corner')

    @include('admin.partials.topbar-right-corner')

</header>