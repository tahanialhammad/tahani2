<?php $__env->startSection('content'); ?>
    <div class="admin-helpcenter d-flex">
        <div class="col-6 me-4">
            <?php echo $__env->make('admin.faq.partials.overview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-6">
            <?php echo $__env->make('admin.faq.partials.addSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.faq.partials.addFaqToSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/tahani2/resources/views/admin/faq/index.blade.php ENDPATH**/ ?>