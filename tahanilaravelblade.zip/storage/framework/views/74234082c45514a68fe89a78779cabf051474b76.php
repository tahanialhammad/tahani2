<?php $__env->startSection('main'); ?>

<?php echo $__env->yieldContent('header'); ?>

<div class="p-4">
  <?php echo $__env->yieldContent('content'); ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/tahani2/resources/views/site/site-template.blade.php ENDPATH**/ ?>