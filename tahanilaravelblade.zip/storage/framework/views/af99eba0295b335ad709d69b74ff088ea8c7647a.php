<header class="topbar sticky-top p-4 d-flex align-items-center justify-content-between bg-white text-dark">

    <?php echo $__env->make('admin.partials.topbar-left-corner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.partials.topbar-right-corner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</header><?php /**PATH /home/vagrant/code/tahani2/resources/views/admin/partials/topbar.blade.php ENDPATH**/ ?>