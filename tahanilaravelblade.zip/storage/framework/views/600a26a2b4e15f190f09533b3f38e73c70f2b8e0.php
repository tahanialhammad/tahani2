<?php $__env->startSection('main'); ?>
<aside class="bg-dark vh-100 text-light" id="nav-bar">
    <?php echo $__env->make('user.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</aside>
<section class="page-content" id="body-pd">
    <div id="app">
        <?php echo $__env->make('user.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="p-4">
            
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/tahani2/resources/views/user/user-template.blade.php ENDPATH**/ ?>