<?php
     $navLinks= collect([
            [
                'name' => 'Dashboard',
                'route' => 'dashboard',
                'icon' => '<icon-home class="icon icon-inverted"></icon-home>'
            ],
            [
                'name' => 'Helpcenter',
                'route' => 'admin.faq.index',
                'icon' => '<icon-info class="icon icon-inverted"></icon-info>'
            ],
        ]);    

// $jsonobj = '{"Peter":35,"Ben":37,"Joe":43}';

// $obj = json_decode($jsonobj);



?>




<nav class="h-100 overflow-hiddenttt overflow-auto">
    <div>
        <!-- brand -->
        <div class="mt-4">
            <a href="/">
                <div class="SidebarLogo"></div>
            </a>
        </div>
        <!-- / brand -->

        <ul class="nav flex-column flex-nowrap text-capitalize mt-5">
            <?php $__currentLoopData = $navLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a class="nav-link d-flex align-items-center text-white" href="<?php echo e(route($navLink['route'])); ?>">
                    <?php echo $navLink['icon']; ?>

                    <span class="ps-3"><?php echo e($navLink['name']); ?></span>
                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</nav><?php /**PATH /home/vagrant/code/tahani2/resources/views/admin/partials/nav.blade.php ENDPATH**/ ?>