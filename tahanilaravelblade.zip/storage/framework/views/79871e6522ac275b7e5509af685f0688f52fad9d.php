<div class="row">
    <div class="col-6">Over our customers</div>
    <div class="col-6">
        <glide-slider></glide-slider>
    </div>
</div><?php /**PATH /home/vagrant/code/tahani2/resources/views/site/home/partials/customers.blade.php ENDPATH**/ ?>