<?php $__env->startSection('content'); ?>

<div id="dashboard">
    <div class="col-xl-9 page-title-v2 pt-4 ps-4">
        <h3 class="fw-bold m-0">
            Hallo <?php echo e(\Auth::user()->name); ?>

        </h3>
    </div>


    <div class="row g-0">
        <div class="col-xl-9 p-4">
            <?php echo $__env->make('admin.dashboard.partials.overview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.dashboard.partials.invoices', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>


        <div class="col-xl-3 px-lg-4 p-4">
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/tahani2/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>