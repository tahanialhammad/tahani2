<div class="left-corner me-3">
    <div id="header-toggle" onclick="this.classList.toggle('open')" class="">
        <span></span>
        <span></span>
        <span></span>
    </div>
</div><?php /**PATH /home/vagrant/code/tahani2/resources/views/user/partials/topbar-left-corner.blade.php ENDPATH**/ ?>