<div class="card p-4 mb-4">
    <div class="card-body">
        <h5 class="card-title">Add FAQ section</h5>
        <div>
            <form method="POST" role="form" action="<?php echo e(route('admin.faq.addOrEditSection')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <input type="text" class="form-control rounded-3 shadow-none <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="name" placeholder="Section name" value="<?php echo e(old('name')); ?>">
                    <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
                </div>

                <div class="mb-3">
                    <input type="number"
                        class="form-control rounded-3 shadow-none <?php $__errorArgs = ['sortOrder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="sortOrder">
                    <div class="invalid-feedback"><?php echo e($errors->first('sortOrder')); ?></div>
                </div>

                <div class="text-end pt-3">
                    <button type="submit" class="btn btn-outline-dark rounded-pill px-5 border-2 fw-bold mx-auto shadow-none">
                     Add section
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/code/tahani2/resources/views/admin/faq/partials/addSection.blade.php ENDPATH**/ ?>