<?php $__env->startSection('main'); ?>
<div class="vh-100">
    <div class="row h-100 g-0">
        <div id="login" class="col bg-white">
        <div>
                <img src="/images/svglogo.svg" alt="logo" class="m-4 logo add-pointer"
                    onclick="location.href='<?php echo e(url('login')); ?>'">
                <div class="d-flex justify-content-center align-items-center h-100">
                    <div class="w-100 m-2" style="max-width: 380px;">
                        <form role="form" method="POST" action="register">
                            <?php echo csrf_field(); ?>
                            <h1 class="fw-bold text-capitalize text-center pb-4"> <?php echo e(__('Register')); ?></h1>

                            <div class="mb-3">
                                <input type="text"
                                    class="form-control rounded-3 shadow-none <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="name" placeholder="Name" value="<?php echo e(old('name')); ?>" required autofocus>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <input type="email"
                                    class="form-control rounded-3 shadow-none <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                                <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                            </div>

                            <div class="mb-3">
                                <input type="password"
                                    class="form-control rounded-3 shadow-none <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="password" placeholder="Password" required>
                                <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div>
                            </div>

                            <div class="mb-3">
                                <input type="password"
                                    class="form-control rounded-3 shadow-none <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Confirm Password" name="password_confirmation" required>
                                <div class="invalid-feedback"><?php echo e($errors->first('password_confirmation')); ?></div>
                            </div>

                            <div class="text-center">
                                <button type="submit" id="register"
                                    class="btn btn-outline-dark rounded-pill px-5 border-2 fw-bold mx-auto shadow-none">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </form>

                        <div class="text-center mt-3">
                            <?php echo e(__('Already registered?')); ?>

                            <a href="<?php echo e(route('login')); ?>"
                                class="link-dark border-bottom border-dark"><?php echo e(__('Log in')); ?></a>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('auth.marketing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/tahani2/resources/views/auth/register.blade.php ENDPATH**/ ?>