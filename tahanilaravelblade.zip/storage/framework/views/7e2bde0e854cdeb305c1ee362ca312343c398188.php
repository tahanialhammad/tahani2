<?php $__env->startSection('main'); ?>
<div class="vh-100">
    <div class="row h-100 g-0">
        <div id="login" class="col bg-white">
        <div>
        <img src="/images/svglogo.svg" alt="tahanina logo" class="m-4 logo add-pointer" onclick="location.href='<?php echo e(url('login')); ?>'">
            <div class="d-flex justify-content-center align-items-center h-100">
                <div class="w-100 m-2" style="max-width: 380px;">
                       <!-- Session Status -->
        

                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                        <h1 class="fw-bold text-capitalize text-center pb-4"> Forgot your password?</h1>
                        <p class="text-center mb-4">No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.</p>

                        <div class="mb-4">
                            <input type="email"
                                   class="form-control rounded-3 shadow-none <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   name="email"
                                   placeholder="Eemail" required autofocus>
                            <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                        </div>

                        <div class="text-center">
                            <button type="submit"
                                    class="btn btn-outline-dark rounded-pill px-5 border-2 fw-bold mx-auto shadow-none">
                                    <?php echo e(__('Email Password Reset Link')); ?>

                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        </div>

        <?php echo $__env->make('auth.marketing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php $__env->stopSection(); ?>















<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/tahani2/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>