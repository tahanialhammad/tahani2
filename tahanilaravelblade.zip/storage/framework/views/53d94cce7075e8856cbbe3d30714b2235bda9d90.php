<?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card mb-2 p-4">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($section->name); ?></h5>
            <div>

                <div class="accordion accordion-flush" id="accordionFlush-<?php echo e($section->id); ?>">
                  <?php $__currentLoopData = $section->faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-heading-<?php echo e($faq->id); ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapse-<?php echo e($faq->id); ?>" aria-expanded="false"
                                aria-controls="flush-collapse-<?php echo e($faq->id); ?>">
                                <?php echo e($faq->question); ?>

                            </button>
                        </h2>
                        <div id="flush-collapse-<?php echo e($faq->id); ?>" class="accordion-collapse collapse"
                            aria-labelledby="flush-heading-<?php echo e($faq->id); ?>" data-bs-parent="#accordionFlush-<?php echo e($section->id); ?>">
                            <div class="accordion-body"><?php echo e($faq->answer); ?></div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    no faq
<?php endif; ?>
<?php /**PATH /home/vagrant/code/tahani2/resources/views/admin/faq/partials/overview.blade.php ENDPATH**/ ?>