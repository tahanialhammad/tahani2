<?php $__env->startSection('content'); ?>
<h1>user content </h1>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('user.user-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/tahani2/resources/views/user/dashboard/index.blade.php ENDPATH**/ ?>