<div class="card p-4">
    <div class="card-body">
        <h5 class="card-title">Add FAQ to a section</h5>
        <div>
            <form method="POST" role="form" action="<?php echo e(route('admin.faq.addOrEditFaq')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <select name="section" class="form-select shadow-none" required>
                        <option selected>Open to select section</option>
                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <input type="text" class="form-control rounded-3 shadow-none <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="question" placeholder="Question tilte" value="<?php echo e(old('question')); ?>">
                    <div class="invalid-feedback"><?php echo e($errors->first('question')); ?></div>
                </div>

                <div class="mb-3">
                    <input type="number"
                        class="form-control rounded-3 shadow-none <?php $__errorArgs = ['sortOrder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="sortOrder">
                    <div class="invalid-feedback"><?php echo e($errors->first('sortOrder')); ?></div>
                </div>
                
                <div class="mb-3">
                    <textarea type="text"
                        class="form-control rounded-3 shadow-none <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="answer" placeholder="Question answer"></textarea>
                    <div class="invalid-feedback"><?php echo e($errors->first('answer')); ?></div>
                </div>

                <div class="text-end pt-3">
                    <button type="submit"
                        class="btn btn-outline-dark rounded-pill px-5 border-2 fw-bold mx-auto shadow-none">
                        Add Faq
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/code/tahani2/resources/views/admin/faq/partials/addFaqToSection.blade.php ENDPATH**/ ?>