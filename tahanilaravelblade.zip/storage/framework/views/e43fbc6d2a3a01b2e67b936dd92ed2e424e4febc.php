
<div>
    <h1>Invoices</h1>
</div>



<?php /**PATH /home/vagrant/code/tahani2/resources/views/admin/dashboard/partials/invoices.blade.php ENDPATH**/ ?>