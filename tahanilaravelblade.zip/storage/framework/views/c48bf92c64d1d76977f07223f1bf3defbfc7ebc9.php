
<?php $__env->startSection('main'); ?>
<div class="vh-100">
    <div class="row h-100 g-0">
        <div id="login" class="col bg-white">
            <div>
                <img src="/images/svglogo.svg" alt="tahanina logo" class="m-4 logo add-pointer" onclick="location.href='<?php echo e(url('login')); ?>'">
                <div class="d-flex justify-content-center align-items-center h-100">
                    <div class="w-100 m-2" style="max-width: 380px;">
                        <form method="POST" role="form" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <h1 class="fw-bold text-capitalize text-center pb-4"> Log in </h1>
                            <div class="mb-3">
                                <input type="email" class="form-control rounded-3 shadow-none <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                                <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                            </div>

                            <div class="mb-3">
                                <input type="password" class="form-control rounded-3 shadow-none <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Password">
                                <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div>
                            </div>

                            <?php
                            $url = \Session::get('url');
                            $intended = $url && isset($url['intended']) ? $url['intended'] : '';
                            $deleteAccount = strpos($intended, 'account/forget/confirm') !== false;
                            ?>

                            <div class="mb-4 pb-2 d-md-flex justify-content-between align-items-center">
                                <div class="form-check form-switch d-flex align-items-end justify-content-center">
                                    <?php if(!$deleteAccount): ?>
                                    <input class="form-check-input border-0 shadow-none" type="checkbox" id="remember-login" name="remember">
                                    <label for="remember-login" class="form-check-label ms-2 d-inline">
                                        <?php echo e(__('Remember me')); ?>

                                    </label>
                                    <?php endif; ?>
                                </div>

                                <div class="text-center">
                                    <?php if(!$deleteAccount): ?>
                                    <a href="<?php echo e(route('password.request')); ?>" class="link-dark border-bottom border-dark">
                                        <?php echo e(__('Forgot your password?')); ?>

                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-outline-dark rounded-pill px-5 border-2 fw-bold mx-auto shadow-none">
                                    <?php if($deleteAccount): ?>
                                    Deleted user
                                    <?php else: ?>
                                    <?php echo e(__('Log in')); ?>

                                    <?php endif; ?>
                                </button>
                                <div class="mt-3">
                                    <?php if(!$deleteAccount): ?>
                                    No account yet?
                                    <a href="<?php echo e(route('register')); ?>" class="link-dark border-bottom border-dark">
                                        <?php echo e(__('Register')); ?>

                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('auth.marketing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/tahani2/resources/views/auth/login.blade.php ENDPATH**/ ?>