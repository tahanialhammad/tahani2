<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

        <!-- Animate on scroll library Styles -->
        <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    </head>
    <body>
        <div id="app" class="bg-white">
            <?php echo $__env->make('layouts.siteNavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
            <header class="bg-white">
                <div class="">
                    <?php echo e($header); ?>

                </div>
            </header>
        <?php endif; ?>

            <!-- Page Content -->
            <main>
                <?php echo $__env->yieldContent('main'); ?>
            </main>
        </div>
    </body>

     <!-- Animate on scroll library Scripts -->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
</html>
<?php /**PATH /home/vagrant/code/tahani2/resources/views/layouts/site.blade.php ENDPATH**/ ?>