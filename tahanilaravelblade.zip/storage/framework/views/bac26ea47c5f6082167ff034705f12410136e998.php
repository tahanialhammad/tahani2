<div>
    <div class="d-flex align-items-center">
        <?php if(auth()->guard()->check()): ?>
            <div class="dropdown">
                <button class="btn btn-link  text-decoration-none dropdown-toggle" type="button" id="dropdownMenuButton1"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo e(Auth::user()->name); ?>

                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    <?php endif; ?>
</div>
</div>
<?php /**PATH /home/vagrant/code/tahani2/resources/views/user/partials/topbar-right-corner.blade.php ENDPATH**/ ?>