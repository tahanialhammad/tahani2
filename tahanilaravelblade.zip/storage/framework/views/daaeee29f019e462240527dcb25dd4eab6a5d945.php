<?php $__env->startSection('header'); ?>
    <div class="col-8 mx-auto my-4 py-5 bg-light rounded ">
        <h1 class="fw-bold text-center mb-4">How can we help you?</h1>
        <div>
            <real-time-search :faqs="<?php echo e(json_encode($allFaqs)); ?>"></real-time-search>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="helpcenter col-8 mx-auto">
        <div class="py-4">
            <h3 class="fw-bold text-center mb-4">Categories</h3>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-3 g-lg-5 bg">
                <?php $__empty_1 = true; $__currentLoopData = $sections->sortBy('sort_order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col">
                        <a href="">
                            <div class="card h-100 text-center shadow">
                                <div class="card-body py-5 ">
                                    <icon-home class="icon-xxl icon-light mb-5"></icon-home>
                                    <h4 class="card-title fw-bold"><?php echo e($section->name); ?></h4>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    No faq items
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.site-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/tahani2/resources/views/site/helpcenter/index.blade.php ENDPATH**/ ?>